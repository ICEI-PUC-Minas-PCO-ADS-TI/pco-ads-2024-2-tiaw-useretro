let indiceSlide = 0;
const slides = document.querySelectorAll('.slider .slide');
const totalSlides = slides.length;

// Função para mudar o slide manualmente
function mudarSlide(direcao) {
    indiceSlide = (indiceSlide + direcao + totalSlides) % totalSlides;
    atualizarSlide();
}

// Função para atualizar a posição do slide
function atualizarSlide() {
    const offset = -indiceSlide * 100;
    document.querySelector('.slider').style.transform = `translateX(${offset}%)`;
}

// Carrossel automático
setInterval(() => {
    mudarSlide(1); // Vai para o próximo slide a cada 5 segundos
}, 5000);

const mobileMenu = document.getElementById('mobile-menu');
const navList = document.getElementById('nav-list');

mobileMenu.addEventListener('click', () => {
navList.classList.toggle('active');
});
